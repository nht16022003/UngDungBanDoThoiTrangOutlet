import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/store_provider.dart';
import 'app.dart';

import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  print("Firebase Connected Successfully");

  runApp(
    ChangeNotifierProvider(
      create: (_) => StoreProvider(),
      child: const MyApp(),
    ),
  );
}
